package dev.homeredirect;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String ADB_CMD =
            "adb shell pm grant dev.homeredirect android.permission.WRITE_SECURE_SETTINGS";
    private TextView status;
    private final List<ResolveInfo> apps = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        PackageManager pm = getPackageManager();

        Set<String> seen = new HashSet<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String p = ri.activityInfo.packageName;
                if (!p.equals(getPackageName()) && seen.add(p)) apps.add(ri);
            }
        }
        Collections.sort(apps, (a, c) ->
                a.loadLabel(pm).toString().compareToIgnoreCase(c.loadLabel(pm).toString()));
        List<String> labels = new ArrayList<>();
        for (ResolveInfo ri : apps) labels.add(ri.loadLabel(pm).toString());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 32, 48, 32);

        status = new TextView(this);
        status.setTextSize(18);
        root.addView(status);

        Button enable = new Button(this);
        enable.setText("Activar servicio");
        enable.setOnClickListener(v -> enableService());
        root.addView(enable);

        root.addView(check("Redirigir el botón Home", "redirect", true));
        root.addView(check("Abrir mi launcher al encender", "boot", false));

        TextView hint = new TextView(this);
        hint.setText("Elige tu launcher:");
        hint.setTextSize(16);
        root.addView(hint);

        ListView list = new ListView(this);
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
        list.setOnItemClickListener((p, v, pos, id) -> {
            Prefs.setTarget(this, apps.get(pos).activityInfo.packageName);
            HomeService.refresh();
            refreshStatus();
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); refreshStatus(); }

    private CheckBox check(String text, String key, boolean def) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setChecked(Prefs.flag(this, key, def));
        c.setOnCheckedChangeListener((v, on) -> Prefs.setFlag(this, key, on));
        return c;
    }

    private boolean serviceOn() {
        String s = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        ComponentName cn = new ComponentName(this, HomeService.class);
        return s != null && (s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString()));
    }

    private void refreshStatus() {
        String t = Prefs.target(this);
        status.setText("Servicio: " + (serviceOn() ? "ACTIVO" : "apagado")
                + "\nDestino: " + (t == null ? "(sin elegir)" : t));
    }

    private void enableService() {
        try {
            String flat = new ComponentName(this, HomeService.class).flattenToString();
            String cur = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (cur == null) cur = "";
            if (!cur.contains(flat)) cur = cur.isEmpty() ? flat : cur + ":" + flat;
            Settings.Secure.putString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, cur);
            Settings.Secure.putInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
            refreshStatus();
        } catch (SecurityException e) {
            Toast.makeText(this, "Falta el permiso. Ejecuta en el PC:\n" + ADB_CMD,
                    Toast.LENGTH_LONG).show();
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception ignored) { }
        }
    }
}

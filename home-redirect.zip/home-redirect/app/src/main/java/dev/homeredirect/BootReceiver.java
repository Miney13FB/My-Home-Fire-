package dev.homeredirect;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (Prefs.flag(c, "boot", false)) Launcher.open(c, Prefs.target(c));
    }
}

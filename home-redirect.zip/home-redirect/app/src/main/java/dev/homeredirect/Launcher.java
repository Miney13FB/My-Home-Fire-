package dev.homeredirect;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

final class Launcher {
    /** Abre el paquete destino. Devuelve false si no se pudo. */
    static boolean open(Context c, String pkg) {
        if (pkg == null) return false;
        PackageManager pm = c.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        try { c.startActivity(i); return true; } catch (Exception e) { return false; }
    }
}

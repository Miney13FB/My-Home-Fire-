package dev.homeredirect;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Detecta que el launcher de Amazon pasó a primer plano (= se pulsó Home)
 * y abre el launcher elegido encima. Solo escucha 2 paquetes y no lee la pantalla.
 */
public class HomeService extends AccessibilityService {
    static final String AMAZON = "com.amazon.tv.launcher";
    private static final long DOUBLE_PRESS_MS = 1500;  // 2.º Home dentro de este margen = escapar a Amazon
    private static final long COVER_MAX_MS = 6000;     // Fire OS 7 retiene el arranque hasta 5 s

    static HomeService instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable hideCover = this::removeCover;
    private long lastRedirect;
    private View cover;

    @Override protected void onServiceConnected() {
        instance = this;
        refresh();
    }

    /** Ajusta el filtro de paquetes: Amazon + el destino (para saber cuándo ya apareció). */
    static void refresh() {
        HomeService s = instance;
        if (s == null) return;
        String t = Prefs.target(s);
        AccessibilityServiceInfo info = s.getServiceInfo();
        if (info == null) return;
        info.packageNames = (t == null) ? new String[]{AMAZON} : new String[]{AMAZON, t};
        s.setServiceInfo(info);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || e.getPackageName() == null) return;
        String pkg = e.getPackageName().toString();
        String target = Prefs.target(this);
        if (target == null) return;

        if (pkg.equals(target)) { removeCover(); return; }
        if (!pkg.equals(AMAZON) || !Prefs.flag(this, "redirect", true)) return;

        long now = SystemClock.uptimeMillis();
        if (now - lastRedirect < DOUBLE_PRESS_MS) {   // doble Home: dejar Amazon
            lastRedirect = 0;
            removeCover();
            return;
        }
        lastRedirect = now;
        showCover();
        if (!Launcher.open(this, target)) removeCover();
    }

    /** Pantalla negra solo en Fire OS 7 (API < 30) para tapar la espera. */
    private void showCover() {
        if (Build.VERSION.SDK_INT >= 30 || cover != null) return;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            View v = new View(this);
            v.setBackgroundColor(Color.BLACK);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.OPAQUE);
            wm.addView(v, lp);
            cover = v;
            h.postDelayed(hideCover, COVER_MAX_MS);
        } catch (Exception ignored) { cover = null; }
    }

    private void removeCover() {
        h.removeCallbacks(hideCover);
        if (cover == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(cover); }
        catch (Exception ignored) { }
        cover = null;
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        removeCover();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}

package dev.homeredirect;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("p", Context.MODE_PRIVATE);
    }
    static String target(Context c) { return sp(c).getString("target", null); }
    static void setTarget(Context c, String pkg) { sp(c).edit().putString("target", pkg).apply(); }
    static boolean flag(Context c, String k, boolean d) { return sp(c).getBoolean(k, d); }
    static void setFlag(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).apply(); }
}

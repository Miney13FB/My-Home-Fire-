# Home Redirect (independiente, inspirado en el concepto de Home on Fire)

1. Compilar: sube esta carpeta a un repo de GitHub -> pestaña Actions -> build -> descarga `home-redirect-apk`.
   (o abre la carpeta en Android Studio y Build > Build APK)
2. Instalar en el Fire TV (Downloader o `adb install app-debug.apk`).
3. Dar permiso una vez (ADB debugging activado en el Fire TV):
   adb connect IP_DEL_FIRE:5555
   adb shell pm grant dev.homeredirect android.permission.WRITE_SECURE_SETTINGS
4. Abrir la app > "Activar servicio" > elegir tu launcher.
